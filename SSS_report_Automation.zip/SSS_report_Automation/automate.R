library(stringr)
library(tidyverse)
df=read.csv("SSSdata.csv",header = T)
df$Programme=as.factor(df$Programme)
Programme <- df$Programme

reports <- tibble(
  filename = str_c("Analysis_Summary-",Programme, ".html"),
  params = map(Programme, ~list(Programme = .))
)

reports %>%
  select(output_file = filename, params) %>%
  pwalk(rmarkdown::render, input = "SSS_report_template.Rmd",output_format = "html_document", output_dir = "output/")
#  pwalk(input = 'my-file.Rmd', output_format = 'pdf_document', output_dir = "output/")
#xfun::Rscript_call(
#  rmarkdown::render,
#  list(input = 'my-file.Rmd', output_format = 'pdf_document', output_dir = "output/")
#)