
#using R version 3.5.0
#Using R Studio 1.2.1518
#Using TexLive 2018
#Using tinyTex package in R

#loading required libraries
library(tidyverse)
library(rmarkdown)
library(stringr)
library(here)

set_here() # insist R engine to stand on the working directory
#loading .csv file containing details of participants
attendees <- read_csv(here("Speaker Details (1).csv")) %>%
mutate(filePDF = str_c("PDF/", row_number(), "_",
                         str_replace_all(Name, fixed(" "), "_"), ".pdf")) %>%
select(filePDF,ID, Name, Designation, Dept,  Event, Institution, Place)
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
certificate <- function(template, count, attendeeName, attendeeDesig, edept, einst, event, eLocation,id,Date, outPDF, knitDir){
  cat("\n Starting:", outPDF, "\n")
  
  # Create a temporary Rmd file with the attendee and event information.  
  templateCert <- read_file(template)
  tmpRmd <- templateCert %>%
    str_replace("<<ID>>", attendeeName) %>%
    str_replace("<<count>>", as.character(count)) %>%
    str_replace("<<ATTENDEE_NAME>>", attendeeName) %>%
    str_replace("<<ATTENDEE_DESIG>>", attendeeDesig) %>%
    str_replace("<<EVENT_DEPT>>", edept) %>%
    str_replace("<<EVENT_INST>>", einst) %>%
    str_replace("<<EVENT_NAME>>", event) %>%
    str_replace("<<EVENT_LOCATION>>", eLocation)%>%
    str_replace("<<EVENT_DATE>>", as.character(count))
  
  # The knitdir has to be defined for the rmarkdown::render to work.
  RmdFile <- tempfile(tmpdir = knitDir, fileext = ".Rmd")
  write_file(tmpRmd, RmdFile)
  
  # Creating the certificates using R markdown.
  rmarkdown::render(RmdFile, output_file = here(outPDF), quiet = TRUE)
  
  # Temporary .Rmd file can be deleted.
  file.remove(RmdFile)
  cat("\n Finished:", outPDF, "\n")
}  
for (i in seq_len(nrow(attendees))) {
  with(attendees,
       certificate(template = here("Certificate_keynoteME.txt"),
                   ID[i], Name[i], Designation[i], Dept[i], Institution[i], Event[i], Place[i],Name[i],Date[i], filePDF[i], here())
  )
}
